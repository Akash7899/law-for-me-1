import React from "react";

const HeaderTop = () => {
  return (
    <>
      <div className="headerTop">
        <div className="container">
          <div className="row">
            <div className="Wrapper">
              <div className="wrapperInner">
                <div className="wrapperin>">
                <img src={require('../assets/images/Vector.png')} />
                  <span>
                    <a href="">Some Offer / CTA goes here / Lorem Ipsum </a>
                  </span>
                </div>
                <div className="wrapperin>">
                    
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HeaderTop;
