import React from "react";
import HeaderTop from "./headerTop";

const Header = () => {
  return (
    <>
      <HeaderTop />
    </>
  );
};

export default Header;
