import React from "react";

const Error = () => {
  return (
    <>
      <div className="container">
        <div className="row">
          <h1>Page Not Found</h1>
        </div>
      </div>
    </>
  );
};

export default Error;
