import React from "react";

const Button = (props) => {
  return (
    <>
      <button className="pinkbutton">{props.Text}</button>
    </>
  );
};

export default Button;
